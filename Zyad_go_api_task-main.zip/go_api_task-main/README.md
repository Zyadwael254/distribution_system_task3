# go_api_task
to run go server on container with docker tech
image(public) link to create container : docker pull seifeldeen/golang_api:v1.0
